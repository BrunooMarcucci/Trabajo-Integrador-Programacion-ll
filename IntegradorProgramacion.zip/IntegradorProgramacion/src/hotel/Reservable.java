package hotel;

public interface Reservable {
    void reservar();
}
