package hotel;

public class DniInvalidoException extends Exception {
    public DniInvalidoException(String mensaje) {
        super(mensaje);
    }
}
